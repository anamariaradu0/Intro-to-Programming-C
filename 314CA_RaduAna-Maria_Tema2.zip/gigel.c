// Copyright 2018 Ana-Maria Radu
#include <stdio.h>
#include <memory.h> // pt memset
#include <stdlib.h>

#define NMAX 100

// Explicarea fiecarei functii in README

// Afisarea matricei
void print_board(int positions, char board[NMAX][NMAX]) {
    for (int i = 0; i < positions; ++i) {
        for (int j = 0; j < positions; ++j) {
            printf("%c", board[i][j]);
        }
        printf("\n");
    }
}

// Initializarea matricei
void empty_board(char board[NMAX][NMAX]) {
    memset(board, '-', NMAX * NMAX);
}

// Verificare validitate index
int is_index_valid(int positions, int x, int y) {
    return x >= 0 && x < positions && y >= 0 && y < positions;
}

// Verificare validitate celula
int is_cell_empty(char board[NMAX][NMAX], int x, int y) {
    return board[x][y] == '-';
}

// Mutare automata dupa algoritmul round-robin
int forced_move(
    char board[NMAX][NMAX], char player, int positions, int *x, int *y
) {
    // prima diagonala
    for (int i = 0; i < positions; ++i) {
        if (is_cell_empty(board, i, i)) {
            board[i][i] = player;
            // pointerii returneaza coordonatele modificate
            *x = i;
            *y = i;
            return 1;
        }
    }
    for (int i = 1; i < positions; ++i) {
        // diagonala de sus
        for (int j = 0; j < positions - i; ++j) {
            if (is_cell_empty(board, j, j + i)) {
                board[j][j + i] = player;
                *x = j;
                *y = j + i;
                return 1;
            }
        }
        // diagonala de jos
        for (int j = 0; j < positions - i; ++j) {
            if (is_cell_empty(board, i + j, j)) {
                board[i + j][j] = player;
                *x = i + j;
                *y = j;
                return 1;
            }
        }
    }
    return 0;
}

// Auxiliara folosita in winner
char aux_winner(char current_winner, int ok_X, int ok_0, int n) {
    if (ok_X == n) {
        if (current_winner == '0') {
            return '-';
        }
        current_winner = 'X';
    } else if (ok_0 == n) {
            if (current_winner == 'X') {
                return '-';
        }
        current_winner = '0';
    }
    return current_winner;
}

// Determinarea castigatorului in board
char winner(int n, int line, int col, char board[NMAX][NMAX]) {
    int ok_X, ok_0;
    char current_winner = '-';
    // verificare pe linii
    for (int i = n * line; i < n * (line + 1); ++i) {
        ok_X = 0;
        ok_0 = 0;
        for (int j = n * col; j < n * (col + 1); ++j)  {
            if (board[i][j] == 'X') {
                ++ok_X;
            }
            if (board[i][j] == '0') {
                ++ok_0;
            }
            current_winner = aux_winner(current_winner, ok_X, ok_0, n);
        }
    }
    // verificare coloane
    for (int j = n * col; j < n * (col + 1); ++j) {
        ok_X = 0;
        ok_0 = 0;
        for (int i = n * line; i < n * (line + 1); ++i) {
            if (board[i][j] == 'X') {
                ++ok_X;
            }
            if (board[i][j] == '0') {
                ++ok_0;
            }
            current_winner = aux_winner(current_winner, ok_X, ok_0, n);
        }
    }
    ok_X = 0;
    ok_0 = 0;
    // verificare diagonala principala
    for (
        int i = n * line, j = n * col;
        i < n * (line + 1) && j < n * (col + 1);
        ++i, ++j
    ) {
        if (board[i][j] == 'X') {
            ++ok_X;
        }
        if (board[i][j] == '0') {
            ++ok_0;
        }
        current_winner = aux_winner(current_winner, ok_X, ok_0, n);
    }
    ok_X = 0;
    ok_0 = 0;
    // verificare diagonala secundara
    for (
        int i = n * line, j = n * (col + 1) - 1;
        i < n * (line + 1) && j >= n * col;
        ++i, --j
    ) {
        if (board[i][j] == 'X') {
            ++ok_X;
        }
        if (board[i][j] == '0') {
            ++ok_0;
        }
        current_winner = aux_winner(current_winner, ok_X, ok_0, n);
    }
    return current_winner;
}

// Determinarea castigatorului in macroboard
void macro_winner(int n, char macroboard[NMAX][NMAX]) {
    int w = winner(n, 0, 0, macroboard);
    if (w == 'X') {
        printf("X won\n");
    } else if (w == '0') {
        printf("0 won\n");
    } else {
        printf("Draw again! Let's play darts!\n");
    }
}

int main() {
    // Explicarea denumirilor variabilelor si a folosirii lor in README
    char board[NMAX][NMAX], macroboard[NMAX][NMAX];
    char player, last_player = '0';
    int n, m, x, y;
    int played_by_X = 0, won_by_X = 0;
    int played_by_0 = 0, won_by_0 = 0;
    int move_type;

    scanf("%d %d", &n, &m);

    int positions = n * n;

    // Initializarea elementelor celor 2 matrici cu '-'
    empty_board(board);
    empty_board(macroboard);

    for (int i = 0; i < m; ++i) {
        scanf(" %c %d %d", &player, &x, &y);

        // Verificarile cerute
        if (player == last_player) {
            printf("NOT YOUR TURN\n");
            // trece la urmatoarea iteratie
            continue;
        }

        if (!is_index_valid(positions, x, y)) {
            printf("INVALID INDEX\n");
            if (!forced_move(board, player, positions, &x, &y)) {
                printf("FULL BOARD\n");
                break;
            } else {
                // Daca programul ajunge la acest else inseamna ca s-a efectuat
                // o mutare fortata
                move_type = 0;
            }
        } else if (!is_cell_empty(board, x, y)) {
            printf("NOT AN EMPTY CELL\n");
            if (!forced_move(board, player, positions, &x, &y)) {
                printf("FULL BOARD\n");
                break;
            } else {
                move_type = 0;
            }
        } else {
            board[x][y] = player;
            // Daca programul ajunge la acest else inseamna ca s-a efectuat o
            // mutare "manuala", introdusa de jucator
            move_type = 1;
        }

        // Retinerea player-ului curent pentru a compara la urmatoarea iteratie
        last_player = player;

        // Contorizarea numarului de jocuri jucate (totalul mutarilor)
        if (player == 'X') {
            ++played_by_X;
        } else {
            ++played_by_0;
        }

        // Determinarea coordonatelor jocului in board
        int game_x = x / n, game_y = y / n;
        // Construirea macroboard-ului
        // Contorizarea numarului de jocuri castigate prin mutarea player-ului
        // (mutari manuale, nu fortate)
        if (is_cell_empty(macroboard, game_x, game_y)) {
            char win = winner(n, game_x, game_y, board);
            macroboard[game_x][game_y] = win;
            if (win == 'X' && move_type == 1) {
                ++won_by_X;
            } else if (win == '0' && move_type == 1) {
                ++won_by_0;
            }
        }
    }

    // Afisarea macroboard-ului
    print_board(n, macroboard);

    // Determinarea castigatorului in macroboard
    macro_winner(n, macroboard);

    // Calcularea si afisarea coeficientilor de atentie
    if (played_by_X == 0) {
        printf("X N/A\n");
    } else {
        printf("X %.10f\n", (double)won_by_X / played_by_X);
    }
    if (played_by_0 == 0) {
        printf("0 N/A\n");
    } else {
        printf("0 %.10f\n", (double)won_by_0 / played_by_0);
    }

    return 0;
}

// Copyright Radu Ana-Maria 2018
#include <stdio.h>
#include <math.h>

// Urmatoarea functie afiseaza "*" sau ".", conform cerintelor problemei
void afisare_pozitie(int ok, int r, int linie, int max_cod, int pozitie) {
    if (ok == 1) {
        printf(
            "%c%s",
            r >= 10 - linie ? '*' : '.',
            pozitie < max_cod ? " " : "");
    }
}

/* Urmatoarea functie afiseaza pe ultima linie a histogramei codurile
serialelor vizionate */
void afisare_cod(int ok, int max_cod, int pozitie) {
    if (ok == 1) {
        printf(
            "%d%s", pozitie,
            pozitie < max_cod ? " " : "");
    }
}

/* Urmatoarea definire a fost facuta cu scopul de a pastra lizibilitatea
in functia main. Se defineste apelul repetat al functiei afisare_pozitie,
cu variabile schimbate */
#define afisare_linie() \
    afisare_pozitie(ok0, r0, linie, max_cod, 0); \
    afisare_pozitie(ok1, r1, linie, max_cod, 1); \
    afisare_pozitie(ok2, r2, linie, max_cod, 2); \
    afisare_pozitie(ok3, r3, linie, max_cod, 3); \
    afisare_pozitie(ok4, r4, linie, max_cod, 4); \
    afisare_pozitie(ok5, r5, linie, max_cod, 5); \
    afisare_pozitie(ok6, r6, linie, max_cod, 6); \
    afisare_pozitie(ok7, r7, linie, max_cod, 7); \
    afisare_pozitie(ok8, r8, linie, max_cod, 8); \
    afisare_pozitie(ok9, r9, linie, max_cod, 9); \
    printf("\n")

/* Urmatoarea definire a fost facuta cu scopul de a pastra lizibilitatea
in functia main. Se defineste apelul repetat al functiei afisare_cod, cu
variabile schimbate */
#define afisare_linie_coduri() \
    afisare_cod(ok0, max_cod, 0); \
    afisare_cod(ok1, max_cod, 1); \
    afisare_cod(ok2, max_cod, 2); \
    afisare_cod(ok3, max_cod, 3); \
    afisare_cod(ok4, max_cod, 4); \
    afisare_cod(ok5, max_cod, 5); \
    afisare_cod(ok6, max_cod, 6); \
    afisare_cod(ok7, max_cod, 7); \
    afisare_cod(ok8, max_cod, 8); \
    afisare_cod(ok9, max_cod, 9); \
    printf("\n")

int main() {
    // Explicarea denumirii si folosirii variabilelor in README
    int n, cod, nr_ep, total_ep, pozitie, max_cod, i, linie;
    int r0, r1, r2, r3, r4, r5, r6, r7, r8, r9;
    int ok0 = 0, ok1 = 0, ok2 = 0, ok3 = 0, ok4 = 0;
    int ok5 = 0, ok6 = 0, ok7 = 0, ok8 = 0, ok9 = 0;
    // Citiri ale n, cod, nr_ep si total_ep
    scanf("%d", &n);
    for (i = 0; i < n; ++i) {
        scanf("%d %d %d", &cod, &nr_ep, &total_ep);
        switch (cod) {
            case 0 :
                // Verificarea gasirii codului respectiv
                ok0 = 1;
                // Rotunjirea numarului de episoade
                r0 = round((10.0 * nr_ep) / total_ep);
                /* Actualizarea max_cod, folosit pentru conditia
                de oprire a functiilor declarate in afara main-ului */
                if (max_cod < 0) max_cod = 0;
                // Terminarea for-ului in cazul in care un cod e gasit
                break;
            case 1 :
                ok1 = 1;
                r1 = round((10.0 * nr_ep) / total_ep);
                if (max_cod < 1) max_cod = 1;
                break;
            case 2 :
                ok2 = 1;
                r2 = round((10.0 * nr_ep) / total_ep);
                if (max_cod < 2) max_cod = 2;
                break;
            case 3 :
                ok3 = 1;
                r3 = round((10.0 * nr_ep) / total_ep);
                if (max_cod < 3) max_cod = 3;
                break;
            case 4 :
                ok4 = 1;
                r4 = round((10.0 * nr_ep) / total_ep);
                if (max_cod < 4) max_cod = 4;
                break;
            case 5 :
                ok5 = 1;
                r5 = round((10.0 * nr_ep) / total_ep);
                if (max_cod < 5) max_cod = 5;
                break;
            case 6 :
                ok6 = 1;
                r6 = round((10.0 * nr_ep) / total_ep);
                if (max_cod < 6) max_cod = 6;
                break;
            case 7 :
                ok7 = 1;
                r7 = round((10.0 * nr_ep) / total_ep);
                if (max_cod < 7) max_cod = 7;
                break;
            case 8 :
                ok8 = 1;
                r8 = round((10.0 * nr_ep) / total_ep);
                if (max_cod < 8) max_cod = 8;
                break;
            case 9 :
                ok9 = 1;
                r9 = round((10.0 * nr_ep) / total_ep);
                if (max_cod < 9) max_cod = 9;
                break;
        }
    }
    // Apelarea primului macro
    for (linie = 0; linie < 10; ++linie) {
        afisare_linie();
    }
    // Apelarea celui de-al doilea macro
    afisare_linie_coduri();

    return 0;
}

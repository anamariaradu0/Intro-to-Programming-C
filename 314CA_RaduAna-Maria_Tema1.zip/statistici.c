// Copyright Radu Ana-Maria 2018
#include <stdio.h>
#include <math.h>

int main() {
    // Explicarea denumirii si folosirii variabilelor in README
    int n, i;
    float x, x_prc, suma = 0, inv_suma = 0, suma_patr = 0, produs = 1;
    float stdev = 0, m_geometrica = 1, m_aritmetica = 0;
    float m_patratica = 0, m_armonica = 0;
    float min = 1000000, max = -1000000;
    int ap_min = 0, ap_max = 0, l = 0, l_max = 0;
    float min_curent, max_curent;
    // Citirea lui n, apoi a lui x in loop-ul for
    scanf("%d", &n);
    for (i = 0; i < n; ++i) {
        // initializarea x_prc cu x, explicata in README
        x_prc = x;
        scanf("%f", &x);
        // Calcularea sumei, produsului, a inversului sumei si sumei patratice
        suma += x;
        produs *= x;
        inv_suma += 1.0 / x;
        suma_patr += pow(x, 2);
        // Calcularea mediei geometrice
        if (x >= 0) {
            m_geometrica *= pow(x, 1.0 / n);
        } else {
            m_geometrica = -1;
        }
        // Calcularea minimului si a numarului de aparitii
        if (x == min) {
            ++ap_min;
        } else {
            if (x < min) {
                min = x;
                ap_min = 1;
            }
        }
        // Calcularea maximului si a numarului de aparitii
        if (x == max) {
            ++ap_max;
        } else {
            if (x > max) {
                max = x;
                ap_max = 1;
            }
        }
        // Calcularea lungimii secventei de numere crescatoare
        if (x >= x_prc) {
            ++l;
            if (l > l_max) {
                l_max = l;
            }
        } else if (x < x_prc) {
            l = 1;
        }
    }
    // Calcularea deviatiei standard, mediilor aritmetica, armonica, patratica
    stdev = sqrt((suma_patr / n) - (pow(suma / n, 2)));
    m_aritmetica = suma / n;
    m_armonica = (1.0 * (1.0 * n / inv_suma));
    m_patratica = sqrt(suma_patr / n);
    // Afisari
    printf("%.4f\n", m_aritmetica);
    if (m_geometrica >= 0) {
        printf("%.4f\n", m_geometrica);
    } else {
        printf("-\n");
    }
    printf("%.4f\n%.4f\n%.4f\n", m_armonica, m_patratica, stdev);
    printf("%.4f %d\n", min, ap_min);
    printf("%.4f %d\n", max, ap_max);
    printf("%d\n", l_max);

    return 0;
}
